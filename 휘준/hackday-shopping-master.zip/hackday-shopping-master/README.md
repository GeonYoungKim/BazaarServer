### NAVER CAMPUS HACKDAY 2018 SUMMER - 단위테스트에 기반한 실시간 타겟팅 공지사항 플랫폼

**운영 서버**

[http://adm-api.wheejuni.com](http://adm-api.wheejuni.com)(Nginx Reverse Proxying)

**Backend-사용 기술**

- Spring Boot 2.0.1
- Embedded Tomcat 8.5.29
- JPA + Hibernate + H2
- Kotlin + Java 

 