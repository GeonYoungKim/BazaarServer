package com.naver.wheejuni.exceptions.domain;

public class NoArticleException extends RuntimeException {

    public NoArticleException(String msg) {
        super(msg);
    }
}
