package com.naver.wheejuni.exceptions.file;

public class NotSupportedFiletypeException extends RuntimeException {

    public NotSupportedFiletypeException(String msg) {
        super(msg);
    }
}
