package com.naver.wheejuni.dto;

public enum UpdateRequestTypes {
    DELETE, UPDATE
}
