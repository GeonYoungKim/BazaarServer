package com.naver.wheejuni.service.specification;

public interface UUIDGenerator {

    long generateUUID();
}
